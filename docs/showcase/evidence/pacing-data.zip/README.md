# Gojomons combat pacing data

Three recorded simulation experiments compare global damage, fatigue, and shield decay. They address different design questions: how quickly an ordinary fight ends, how the rules handle exceptional stalls, and how long shielding retains value.

The measurements were recorded on **July 27, 2026**. This bundle recomputes their summaries from the saved battle records; it does not run the game.

## Reproduce

Python 3.10 or newer is sufficient. There are no third-party dependencies.

```sh
python analyze_pacing.py --data-root ./data --output ./recomputed
```

The two generated files should match the included `pacing-results.json` and `pacing-summary.csv` exactly. The script checks record validity and matching scenario fields before producing results.

## What is included

- `data/damage_feel_2026-07-27/`: twelve damage conditions across team sizes 1, 3, and 6, plus the archived species/style table.
- `data/damage_fatigue_interaction_2026-07-27/`: four damage × fatigue conditions for six-creature teams.
- `data/shield_decay_2026-07-27/`: eight shield-decay conditions across team sizes 3 and 6.
- `pacing-summary.csv`: condition-level means, quantiles, counts, and matched outcome changes.
- `pacing-results.json`: the same results with turn histograms, descriptive offensive-profile comparisons, source hashes, and pairing metadata.
- `manifest-sha256.json`: hashes of the included data, analysis, and result files.

Several control files are intentionally shared between experiments. They are reused observations, not additional independent battles. `reused_controls` identifies these equivalences.

## Reading the records

Each raw CSV row is one simulated battle. `i` identifies the scenario, `seed` its battle RNG seed, `party` and `enemy` the ordered species lists, `team` the number of creatures on each side, and `format` the active battle format. A team of six uses two active creatures at a time. `turns` counts simulation rounds; `timed_out` marks battles unresolved at the 120-round cap. `victor` distinguishes player wins, enemy wins, mutual draws, and timeouts. Relics are player-side equipment in these experiments.

Within each format, conditions retain the same recorded species, order, level, seeds, and relic lists. The archived producer also fixes authored styles and constructs stats, moves, and held items deterministically. Full input dictionaries were not saved, so the package verifies the retained pairing fields rather than reconstructing every historical engine input.

The JSON's `source` fields preserve **original project-relative provenance paths** beginning `DOCUMENTATION/design_bible/data/`. Their corresponding files in this bundle are under `data/`, followed by the same study directory and filename. No original game installation is required.

## Interpretation

For six-creature teams, damage 1.0 → 1.5 moved median fight length from 22 → 16 rounds. With damage held at 1.5, fatigue reduced cap counts from 10 → 1 out of 800 while the median stayed 16. At damage 1.0, shield decay 0 → .25 moved the median from 22 → 21 and the count above 60 rounds from 60 → 45 out of 800.

These are descriptions of the recorded batches. Capped fights are unresolved by round 120, not necessarily infinite. Offensive-profile comparisons group different species; they do not isolate a causal effect of assigning a style. Draws and timeouts receive half credit in those comparisons. Quantiles use linear interpolation at index `(n-1)*p`.

The selected damage 1.5 and shield decay .25 remain in the September 11 configuration; other mechanics, including fatigue growth, have changed. The July outcome rates should therefore be read as historical design evidence.
