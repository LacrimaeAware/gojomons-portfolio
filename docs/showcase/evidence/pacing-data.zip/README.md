# Gojomons combat pacing data

Three simulation experiments compare global damage, fatigue, and shield decay. They address different design questions: how quickly an ordinary fight ends, how the rules handle exceptional stalls, and how long shielding retains value.

The measurements were recorded on **July 27, 2026**.

## Analysis

Run with Python 3.10 or newer:

```sh
python analyze_pacing.py --data-root ./data --output ./recomputed
```

## Files

- `data/damage_feel_2026-07-27/`: twelve damage conditions across team sizes 1, 3, and 6, plus the species/style table.
- `data/damage_fatigue_interaction_2026-07-27/`: four damage × fatigue conditions for six-creature teams.
- `data/shield_decay_2026-07-27/`: eight shield-decay conditions across team sizes 3 and 6.
- `pacing-summary.csv`: condition-level means, quantiles, counts, and matched outcome changes.
- `pacing-results.json`: the same results with turn histograms, offensive-profile comparisons and pairing metadata.

Several control files are shared between experiments. They are reused observations, not additional independent battles. `reused_controls` identifies these equivalences.

## Reading the records

Each raw CSV row is one simulated battle. `i` identifies the scenario, `seed` its battle RNG seed, `party` and `enemy` the ordered species lists, `team` the number of creatures on each side, and `format` the active battle format. A team of six uses two active creatures at a time. `turns` counts simulation rounds; `timed_out` marks battles unresolved at the 120-round cap. `victor` distinguishes player wins, enemy wins, mutual draws, and timeouts. Relics are player-side equipment in these experiments.

Within each format, conditions use the same species, order, level, seeds, and relic lists. Creatures use their authored styles; stats, moves, and held items are constructed deterministically.

## Results

For six-creature teams, damage 1.0 → 1.5 moved median fight length from 22 → 16 rounds. With damage held at 1.5, fatigue reduced cap counts from 10 → 1 out of 800 while the median stayed 16. At damage 1.0, shield decay 0 → .25 moved the median from 22 → 21 and the count above 60 rounds from 60 → 45 out of 800.

Offensive-profile comparisons group different species. Draws and timeouts receive half credit in those comparisons. Quantiles use linear interpolation at index `(n-1)*p`.

The September 11 configuration keeps damage 1.5 and shield decay .25. Fatigue now includes a 1.35 growth factor that was absent from the July configuration.
